# 霜淇淋的錢：免費本機製作包

正式網站：https://isaiahovercomer.github.io/numbered-score-studio/family-story-365/

## 先看成果

開啟 silent-preview.mp4：27 秒、1280×720、六場景、緩慢推近的無聲鏡頭預覽。
這不是完成的敘事影片，尚無旁白、字幕與角色動作。插畫為原創程式化 SVG，非 AI 模型生圖。

storyboard.md 是四版本共 21 頁旁白與畫面對照；narration.json 可供後續工具直接讀取。
images 內有六組可編輯 SVG 和 PNG；角色用色保持一致。

## 第一步：在 Windows 產生六頁故事劇場旁白

解壓縮整個資料夾。在該資料夾開啟 Windows PowerShell，執行：

```powershell
powershell.exe -NoProfile -File .\narrate.ps1
```

使用 Windows 已安裝、可供 System.Speech 使用的 zh-TW 聲音；不需顯示卡、API key 或付費服務。
程式列出可用聲音，預設挑台灣中文。沒有台灣中文聲音時明確停止，不自動換口音。
部分 Windows 自然聲音僅供其他介面使用，安裝後不保證出現在 System.Speech 清單。
本包不修改登錄檔或執行原則。如果出現「禁止執行指令碼」，請保留錯誤訊息以便處理。

每次輸出到新的 audio-日期時間 資料夾，包含 theatre-01.wav 至 theatre-06.wav。
先逐頁試聽，確認「霜淇淋」、語氣與停頓。系統聲音只是免費流程試作，不保證自然親切。

其他版本：

```powershell
powershell.exe -NoProfile -File .\narrate.ps1 -Mode all
```

all 共21頁；也可指定 toddler、comic、reader。
可用 -VoiceName '清單中的完整名稱' 選聲音；-Rate -2 為預設稍慢速度。

## 第二步：把聲音與插畫組成影片

需要 Python 3 與 FFmpeg，並讓 ffmpeg 可從終端機執行。
Python：https://www.python.org/downloads/
FFmpeg：https://ffmpeg.org/download.html

在本資料夾執行，下方音檔資料夾名稱請換成第一步實際產生的名稱：

```powershell
python .\make_video.py --audio-dir .\audio-20261028-120000-000 --output .\story-with-voice.mp4
```

影片按每頁 WAV 的實際長度換場，頁尾留半秒，輸出 H.264 / AAC 的 720p MP4。
缺少任何一頁聲音或圖片會停止；不會把無聲影片誤當成有旁白成果。
輸出同名檔已存在時會停止，請改用新的 --output 名稱。
目前不產生字幕，也不產生角色肢體動畫。

## 下一步的開源工具選擇

- 插畫：ComfyUI https://github.com/Comfy-Org/ComfyUI
  逐場生成並人工確認同一家庭的服裝、臉型與人數。先確認硬體，再選模型與畫面尺寸。
- 更自然的中文旁白：GPT-SoVITS https://github.com/RVC-Boss/GPT-SoVITS
  可作中文語音試作；若用參考聲音，使用自己的聲音或取得授權的錄音。
  模型、依賴與參考聲音尚未下載或安裝。須試聽台灣用語、多音字與整篇穩定度。
- 敘事影片組裝：FFmpeg https://github.com/FFmpeg/FFmpeg
  本包以固定分鏡與音檔組裝，適合先完成一篇再擴充批次流程。

## 驗證與限制

已核對21頁資料均對應現有網站文字；六張PNG可讀；無聲影片27秒、1280×720。
已用六個人工產生的1秒靜音WAV驗證有音軌組裝路徑，得到約9秒、H.264+AAC影片。
測試用靜音檔未放入本包，不能視作中文旁白已完成。
Windows PowerShell 腳本未在真實 Windows 上執行；中文聲音音質與可用性待本機驗證。
此包尚未接入線上網站，也沒有自動上傳功能。

技術依據：
https://learn.microsoft.com/en-us/dotnet/api/system.speech.synthesis.speechsynthesizer?view=netframework-4.8.1
https://learn.microsoft.com/en-us/dotnet/api/system.speech.synthesis.speechsynthesizer.setoutputtowavefile?view=netframework-4.8.1
https://ffmpeg.org/ffmpeg-filters.html

故事來源為使用者提供「家庭時光365」真-10；四版本為示範改寫及注音校對稿，不宣告原教材為公有領域。
