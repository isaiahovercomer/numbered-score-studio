﻿param([string]$Mode = 'theatre', [string]$VoiceName = '', [int]$Rate = -2)
$ErrorActionPreference = 'Stop'
if (-not $PSScriptRoot) { throw '請使用 powershell.exe -File narrate.ps1 執行。' }
Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    $voices = @($synth.GetInstalledVoices() | Where-Object {
        $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'zh-*'
    } | ForEach-Object { $_.VoiceInfo })
    if ($voices.Count -eq 0) {
        throw '找不到 System.Speech 可用的中文聲音。請先安裝 Windows 中文語音；部分自然聲音不支援此介面。'
    }
    $voices | Select-Object Name, Culture | Format-Table | Out-Host
    if ($VoiceName) {
        $voice = $voices | Where-Object { $_.Name -eq $VoiceName } | Select-Object -First 1
        if (-not $voice) { throw '指定的聲音不存在，請使用上方列出的完整名稱。' }
    } else {
        $voice = $voices | Where-Object { $_.Culture.Name -eq 'zh-TW' } | Select-Object -First 1
        if (-not $voice) { throw '沒有台灣中文聲音。若要測試其他中文聲音，請用 -VoiceName 明確指定。' }
    }
    if ($Rate -lt -10 -or $Rate -gt 10) { throw 'Rate 必須介於 -10 至 10。' }
    $data = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'narration.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $pages = @($data.pages | Where-Object { $Mode -eq 'all' -or $_.mode -eq $Mode })
    if ($pages.Count -eq 0) { throw 'Mode 可用 toddler、theatre、comic、reader 或 all。' }
    $run = Join-Path $PSScriptRoot ('audio-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    New-Item -ItemType Directory -Path $run | Out-Null
    $synth.SelectVoice($voice.Name)
    $synth.Rate = $Rate
    foreach ($page in $pages) {
        $dest = Join-Path $run ($page.id + '.wav')
        $synth.SetOutputToWaveFile($dest)
        $synth.Speak([string]$page.text)
        $synth.SetOutputToNull()
        if ((Get-Item -LiteralPath $dest).Length -le 44) { throw ('音檔輸出失敗：' + $page.id) }
        Write-Host ('已產生：' + $page.id + '.wav')
    }
    Write-Host ('完成，請先逐頁試聽：' + $run)
} finally { $synth.Dispose() }
