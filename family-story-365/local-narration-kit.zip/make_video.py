"""以固定旁白長度組裝影片；--silent-preview 僅作無聲流程測試。"""
import argparse
import json
import math
from pathlib import Path
import shutil
import subprocess
import tempfile
import wave

ROOT = Path(__file__).resolve().parent

def run(*args):
    subprocess.run(args, check=True, stdout=subprocess.DEVNULL)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audio-dir', type=Path)
    parser.add_argument('--silent-preview', action='store_true')
    parser.add_argument('--output', type=Path, default=ROOT / 'story-theatre.mp4')
    args = parser.parse_args()
    if not shutil.which('ffmpeg'):
        parser.error('找不到 FFmpeg，請先安裝並加入 PATH。')
    if args.output.exists():
        parser.error('輸出已存在，請用 --output 指定新檔名。')
    if args.silent_preview == bool(args.audio_dir):
        parser.error('請選擇 --audio-dir 或 --silent-preview 其中一項。')
    pages = [p for p in json.loads((ROOT / 'narration.json').read_text(encoding='utf-8'))['pages']
             if p['mode'] == 'theatre']
    inputs = []
    for p in pages:
        image = ROOT / p['image']
        if not image.is_file():
            parser.error('缺少插畫：' + str(image))
        audio = args.audio_dir / (p['id'] + '.wav') if args.audio_dir else None
        duration = 4.0
        if audio:
            if not audio.is_file():
                parser.error('缺少旁白：' + str(audio))
            with wave.open(str(audio), 'rb') as w:
                duration = w.getnframes() / w.getframerate()
            if duration <= 0:
                parser.error('旁白沒有內容：' + str(audio))
        inputs.append((image, audio, duration))
    with tempfile.TemporaryDirectory(prefix='story-video-') as temp:
        folder = Path(temp)
        for i, (image, audio, duration) in enumerate(inputs):
            frames = math.ceil((duration + 0.5) * 24)
            # 8:5 插畫完整放入 16:9 畫布，緩慢推近；不裁切原圖邊緣。
            vf = ("scale=1152:720,pad=1280:720:64:0:color=0xfbf8f0,"
                  "zoompan=z='min(1+on*0.00015,1.02)':"
                  "x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=1280x720:fps=24,format=yuv420p")
            cmd = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-loop', '1', '-framerate', '24', '-i', str(image)]
            if audio:
                cmd += ['-i', str(audio), '-af', 'apad=pad_dur=0.5', '-c:a', 'aac', '-ar', '48000', '-ac', '2']
            else:
                cmd += ['-an']
            cmd += ['-vf', vf, '-t', str(frames / 24), '-c:v', 'libx264', '-preset', 'fast',
                    '-threads', '2', '-crf', '22', str(folder / f'{i}.mp4')]
            run(*cmd)
        listing = folder / 'clips.txt'
        listing.write_text(''.join(f"file '{i}.mp4'\n" for i in range(len(inputs))), encoding='utf-8')
        run('ffmpeg', '-hide_banner', '-loglevel', 'error', '-f', 'concat', '-safe', '1',
            '-i', str(listing), '-c', 'copy', '-movflags', '+faststart', str(args.output.resolve()))
    print('完成：', args.output)
    if args.silent_preview:
        print('這是無聲鏡頭預覽，尚未加入旁白。')

if __name__ == '__main__':
    main()
