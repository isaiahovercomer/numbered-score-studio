# 第一篇故事：離線 AI 朗讀製作包

網站使用 MeloTTS-Chinese 的合成女聲試聽版。並非真人錄音，尚未完成台灣口音與多音字聽校。
在本次 Linux CPU 環境已產生四版本21頁音檔，以及49.44秒有聲影片。Windows流程尚未實機測試。

## Windows 本機操作

安裝Python 3.12與FFmpeg，確認 `python --version`、`ffmpeg -version` 可以執行。
解壓本製作包後，在該資料夾開啟PowerShell。以下使用Python，不需要執行.ps1或更改執行原則。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
curl.exe -L --fail https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-melo-tts-zh_en.tar.bz2 -o model.tar.bz2
tar -xf model.tar.bz2
.\.venv\Scripts\python.exe generate_narration.py --model-dir vits-melo-tts-zh_en --script narration.json --output audio
python make_video.py --audio-dir audio --output story-theatre.mp4
```

model.onnx應為170429550位元組，若不符請重新下載解壓。首次下載需要網路；模型準備好後生成語音不呼叫雲端服務。
音檔會輸出到audio資料夾，包括每頁WAV、MP3和記錄每句時間的narration-assets.json。
輸出已存在時腳本會停止，請改用新資料夾；例如 `--output audio-v2`。

影片字幕附本次生成的narrated.zh-TW.vtt。若修改稿件或語速，須依新manifest逐句時間重製字幕；不能沿用舊時間。
影片每頁長度為WAV長度加0.5秒，再向上取整至24fps影格。字幕時間須累加這個頁長。
原故事出處及改寫仍依網站說明；插畫為原有SVG示範，非此次AI生成。

## 模型與引擎來源

- sherpa-onnx：https://github.com/k2-fsa/sherpa-onnx （Apache-2.0）
- MeloTTS：https://github.com/myshell-ai/MeloTTS （MIT）
- 模型：https://huggingface.co/myshell-ai/MeloTTS-Chinese
- 轉換模型：https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models
- 模型授權原文：MODEL-LICENSE.txt

本包不包含大型模型或字型；未呼叫付費雲端。
